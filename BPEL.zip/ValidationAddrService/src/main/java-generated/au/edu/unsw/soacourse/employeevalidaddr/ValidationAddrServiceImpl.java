package au.edu.unsw.soacourse.employeevalidaddr;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;

import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.jws.WebService;

@WebService(endpointInterface = "au.edu.unsw.soacourse.employeevalidaddr.ValidationAddr")
public class ValidationAddrServiceImpl implements ValidationAddr {
	
	ObjectFactory objFact = new ObjectFactory();
	String catHome = System.getProperty("catalina.home");
	
	@Override
	public ValidationAddressResponse validAddressData(
			ValidationAddressRequest parameters)
			throws ValidationAddressFaultMsg {
		
		ValidationAddressResponse res = objFact.createValidationAddressResponse();
		boolean foundByAddress = false;
		//Copy file
		copyFile();
		
		System.out.println("Received " + parameters.address + " " + parameters.fullName);
		/*
		if (parameters.address == null || parameters.address.length() < 2) {
			String msg = "Must have a proper address of at least 3 characters";
			String errCode = "600";
			ServiceFaultType sf = objFact.createServiceFaultType();
			sf.setErrtext(msg);
			sf.setErrcode(errCode);
			
			ValidationAddressFaultMsg nullFault = new ValidationAddressFaultMsg(msg, sf);
			throw nullFault;
		} 
		
		if (parameters.fullName == null || parameters.fullName.length() < 2) {
			String msg = "Must have a proper name of at least 3 letters";
			String errCode = "601";
			ServiceFaultType sf = objFact.createServiceFaultType();
			sf.setErrtext(msg);
			sf.setErrcode(errCode);
			
			ValidationAddressFaultMsg nullFault = new ValidationAddressFaultMsg(msg, sf);
			throw nullFault;
		} */
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			File inputFile = new File(catHome+"/webapps/ROOT/ValidEmployee/validEmployee.xml");
			DocumentBuilder dBuilder = factory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
	        doc.getDocumentElement().normalize();
	        NodeList nList = doc.getElementsByTagName("person");
	        
	        for (int temp = 0; temp < nList.getLength(); temp++) {
	        	Node nNode = nList.item(temp);
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	            	Element eElement = (Element) nNode;
	            	
            		if (eElement.getElementsByTagName("address").item(0) != null && parameters.address != null) {
            			//System.out.println(eElement.getElementsByTagName("fullname").item(0).getTextContent());
            			//System.out.println(eElement.getElementsByTagName("address").item(0).getTextContent());
	            		String addr = eElement.getElementsByTagName("address").item(0).getTextContent();
            			String fname = eElement.getElementsByTagName("fullname").item(0).getTextContent();
            			String paddr = parameters.address;
            			String pfname = parameters.fullName;
            			System.out.println(addr.contentEquals(paddr));
            			System.out.println(fname.contentEquals(pfname));
            			if(addr.contentEquals(paddr) && fname.contentEquals(pfname)) {
	            			foundByAddress = true;
	            			break;
	            		}
	            	} else {
	            		System.out.println("No address");
	            	}
	            }
	         }
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (foundByAddress) {
			res.responseMsg = "Verified Person Exists By Address";
			BigInteger status = new BigInteger("1");
			res.status = status;
		} else {
			res.responseMsg = "Person does not exist";
			BigInteger status = new BigInteger("0");
			res.status = status;
		}
		
		return res;
		//return null;
	}

	private void copyFile() {
		if (catHome == null) {
			catHome = System.getenv("CATALINA_HOME");
		}
		
		//Copy the xml file to the right location
		File file = new File(catHome+"/webapps/ROOT/ValidEmployee");
		file.mkdir();
		
		Path src = Paths.get(catHome+"/webapps/ValidationAddrService/WEB-INF/validEmployee.xml");
		Path dst = Paths.get(catHome+"/webapps/ROOT/ValidEmployee/validEmployee.xml");
		try {
			Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e1) {
			System.out.println("Did not find validEmployee.xml");
			e1.printStackTrace();
		}
	}

}
