@javax.xml.bind.annotation.XmlSchema(namespace = "http://employeevalidaddr.soacourse.unsw.edu.au")
package au.edu.unsw.soacourse.employeevalidaddr;
