package au.edu.unsw.soacourse.employeevalidlic;
import java.io.File;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

@WebService(endpointInterface = "au.edu.unsw.soacourse.employeevalidlic.ValidationLicense")
public class ValidationLicenseServiceImpl implements ValidationLicense {
	ObjectFactory objFact = new ObjectFactory();
	String catHome = System.getProperty("catalina.home");
	
	@Override
	public ValidationLicenseResponse validLicenseData(
			ValidationLicenseRequest parameters)
			throws ValidationLicenseFaultMsg {
		
		ValidationLicenseResponse res = objFact.createValidationLicenseResponse();
		boolean foundByLicense = false;
		
		System.out.println("Received " + parameters.licenseNumber + " " + parameters.fullName);
		copyFile();
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			File inputFile = new File(catHome+"/webapps/ROOT/ValidEmployee/validEmployee.xml");
			DocumentBuilder dBuilder = factory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
	        doc.getDocumentElement().normalize();
	        NodeList nList = doc.getElementsByTagName("person");
	        
	        for (int temp = 0; temp < nList.getLength(); temp++) {
	        	Node nNode = nList.item(temp);
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	            	Element eElement = (Element) nNode;
	            	//System.out.println(eElement.getElementsByTagName("fullname").item(0).getTextContent());
            		if (eElement.getElementsByTagName("licenseNumber").item(0) != null && parameters.licenseNumber != null) {
	            		if(eElement.getElementsByTagName("licenseNumber").item(0).getTextContent().contentEquals(parameters.licenseNumber) &&
	            				eElement.getElementsByTagName("fullname").item(0).getTextContent().contentEquals(parameters.fullName)) {
	            			foundByLicense = true;
	            			break;
	            		}
	            	}
	            }
	         }
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (foundByLicense) {
			res.responseMsg = "Verified Person Exists By License";
			BigInteger status = new BigInteger("1");
			res.status = status;
		} else {
			res.responseMsg = "Person does not exist";
			BigInteger status = new BigInteger("0");
			res.status = status;
		}
		
		return res;
		//return null;
	}

	//Copy file to right location
	private void copyFile() {
		
		if (catHome == null) {
			catHome = System.getenv("CATALINA_HOME");
		}
		
		//Copy the xml file to the right location
		File file = new File(catHome+"/webapps/ROOT/ValidEmployee");
		file.mkdir();
		
		Path src = Paths.get(catHome+"/webapps/ValidationLicService/WEB-INF/validEmployee.xml");
		Path dst = Paths.get(catHome+"/webapps/ROOT/ValidEmployee/validEmployee.xml");
		try {
			Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e1) {
			System.out.println("Did not find validEmployee.xml");
			e1.printStackTrace();
		}
	}
}
