package au.edu.unsw.soacourse.employeevalid;

import javax.jws.WebService;

@WebService
public interface HelloWorld {
    String sayHi(String text);
}

