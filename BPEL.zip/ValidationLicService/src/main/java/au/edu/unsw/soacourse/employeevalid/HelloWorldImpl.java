
package au.edu.unsw.soacourse.employeevalid;

import javax.jws.WebService;

@WebService(endpointInterface = "au.edu.unsw.soacourse.employeevalid.HelloWorld")
public class HelloWorldImpl implements HelloWorld {

    public String sayHi(String text) {
        return "Hello " + text;
    }
}

